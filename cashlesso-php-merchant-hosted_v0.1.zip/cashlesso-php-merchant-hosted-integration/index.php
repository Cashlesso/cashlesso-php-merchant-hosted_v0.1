<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport"
	content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet"
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script
	src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script
	src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous"></script>
<!-- Bootstrap CSS -->
<style>
		* {
		  box-sizing: border-box;
		}
		.signuptextfield{
			width:75%;
		}
		
		
		label {
		  padding: 12px 12px 12px 0;
		  display: inline-block;
		}
		
		input[type=submit] {
		  background-color: #4CAF50;
		  color: white;
		  padding: 12px 20px;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		  float: right;
		}
		
		input[type=submit]:hover {
		  background-color: #45a049;
		}
		
		.container {
			text-align: center;
		  border-radius: 5px;
		  background-color: #f2f2f2;
		  padding: 20px;
		}
		
		.col-25 {
		  float: left;
		  width: 50%;
		  margin-top: 6px;
		}
		
		.col-75 {
		  float: left;
		  width: 50%;
		  margin-top: 6px;
		}
		
		/* Clear floats after the columns */
		.row:after {
		  content: "";
		  display: table;
		  clear: both;
		}
		.jumbotron .container {
    max-width: 50% !important;
}
.jumbotron {
	background-color: white !important;
}
.football_icon{
	width:50px;
}
		
		/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
		@media screen and (max-width: 600px) {
		  .col-25, .col-75, input[type=submit] {
			width: 100%;
			margin-top: 0;
		  }
		}
		</style>
		<script>
	function generateOrderId(){
		document.getElementById("ORDER_ID").value = "CASH"
			+ String(new Date().getTime());
	}	
			
</script>
<title>Cashlesso MerchantHosted PHP Kit</title>

</head>
<body onload="generateOrderId()">
	<div class="jumbotron text-center">
		<img src="images/cashlesso.png";/>
		<h2>Cashlesso Merchant Hosted Page</h2>
		<div>
		<form method="post" action="http://localhost/MerchantHosted_PhpKit/Request.php">		
				<div class="container">
				 
						<div class="row">
						  <div class="col-25">
							<label for="fname">PAY ID:</label>
						  </div>
						  <div class="col-75">
							<input name="PAY_ID" id ="PAY_ID" value="1004491024083052" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">ORDER ID:</label>
						  </div>
						  <div class="col-75">
							<input name="ORDER_ID" id="ORDER_ID" value="CASH" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">CARD NO:</label>
						  </div>
						  <div class="col-75">
							<input name="CARD_NUMBER" value="4012001037141112" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">EXPIRY DATE:</label>
						  </div>
						  <div class="col-75">
							<input name="CARD_EXP_DT" value="122020" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">CVV:</label>
						  </div>
						  <div class="col-75">
							<input name="CVV" value="123" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">CUST NAME:</label>
						  </div>
						  <div class="col-75">
							<input name="CARD_HOLDER_NAME" value="ROHIT" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">PAYMENT TYPE:</label>
						  </div>
						  <div class="col-75">
							<input name="PAYMENT_TYPE" value="CARD" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">MOP TYPE:</label>
						  </div>
						  <div class="col-75">
							<input name="MOP_TYPE" value="" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">AMOUNT:</label>
						  </div>
						  <div class="col-75">
							<input name="AMOUNT" value="1000" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">CURRENCY CODE:</label>
						  </div>
						  <div class="col-75">
							<input name="CURRENCY_CODE" value="356" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="lname">Email:</label>
						  </div>
						  <div class="col-75">
							<input type="email" name="CUST_EMAIL" value="rohit@cashlesso.com" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="country">Phone:</label>
						  </div>
						  <div class="col-75">
							<input type="number" name="CUST_PHONE" value="9811679359" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">RETURN URL:</label>
						  </div>
						  <div class="col-75">
							<input name="RETURN_URL" value="http://localhost/MerchantHosted_PhpKit/Response.php" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <div class="col-25">
							<label for="fname">Request URL:</label>
						  </div>
						  <div class="col-75">
							<input name="requestUrl" value="https://uat.cashlesso.com/pgui/jsp/merchantPaymentInit" class="signuptextfield">
						  </div>
						</div>
						<div class="row">
						  <input type="submit" id="button"
						  class="btn btn-success" value="Pay Now">
						</div>
					  </div>
					  </form>
				</div>
		</div>
</body>
</html>