<?php


//Encryption Key
	
    $CryptoKey= "8228E7F4ED8C5797462B1F48A363E9E7";

//First 16 digits of Key

    $iv = substr($CryptoKey, 0, 16); 

//Encryption method  

    $method = "AES-256-CBC";

//salt

     $salt = "bddd4a686ada4a1d";



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$request_array = filter_input_array(INPUT_POST);
	 


                foreach ($request_array as $key => $value) {

                        $requestParamsJoined[] = "$key=$value";
                    }
                  
                $requestString= requestString($requestParamsJoined, $salt);
                $ciphertext = openssl_encrypt($requestString, $method, $CryptoKey, OPENSSL_RAW_DATA, $iv);
				$ENCDATA= base64_encode($ciphertext);
				$PAY_ID = $request_array["PAY_ID"];
				 
                
               echo 'Please do not Refresh and press the Backbutton of your Browser';
                 
            $form = '<form id="cashlesso_checkout" name="cashlesso_checkout" method="POST" action="' . $request_array["requestUrl"]  . '">';
         	$form .= '<input type="hidden" name="PAY_ID" value="'.$PAY_ID.'" />'."\n";
            $form .= '<input type="hidden" name="ENCDATA" value="'.$ENCDATA.'" />'."\n";
         
         
          
        $form .= '</form>';
        $html = '<html><body>';
       $html = '<script type="text/javascript">
				window.onload=function(){ 
     			document.cashlesso_checkout.submit();};
 
     			</script>';
        $html .= $form;
        $html.= '</body></html>';
        echo $html;
        exit;

  
}exit(0);


/*
* function for generating hash
*/
function requestString($array, $salt_key) {

    sort($array);
    $merchant_data_string = implode('~', $array);
    $format_Data_string = $merchant_data_string . $salt_key;
    $hashData_uf = hash('sha256', $format_Data_string);
    $hashData = strtoupper($hashData_uf);
    $hashValue='~HASH='.$hashData;
    $finalString = $merchant_data_string.$hashValue;
    return $finalString;
}


?>
 