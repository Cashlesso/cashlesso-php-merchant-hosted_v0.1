Cashlesso Php Merchant Hosted Kit:

______________________________________________________________
request.php
______________________________________________________________

This request.php will create the request and send to 3ds Page.
Please enter these to variables ($CryptoKey,$salt).
These variables are given by cashlesso.


______________________________________________________________
response.php
______________________________________________________________

This request.php will create the request and send to 3ds Page.
Please enter these to variables ($CryptoKey,$salt).
These variables are given by cashlesso.


