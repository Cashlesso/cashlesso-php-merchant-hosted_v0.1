<?php

//Encryption method (TO be kept as is)

    $method = "AES-256-CBC";

//salt
    $salt = "bddd4a686ada4a1d";

//Encryption Key
	
    $CryptoKey= "8228E7F4ED8C5797462B1F48A363E9E7";

//First 16 digits of Key

    $iv = substr($CryptoKey, 0, 16); 


$sortedString="";
$hash = "";
$responseCode = "";
$status = "";



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

 $responce_array = filter_input_array(INPUT_POST);

 $ENCDATA = $responce_array['ENCDATA'];
 $PAY_ID = $responce_array['PAY_ID'];

 $plaintext  = openssl_decrypt($ENCDATA, $method, $CryptoKey, 0, $iv);
 $merchant_data_string = explode('~', $plaintext);
 sort($merchant_data_string);

foreach($merchant_data_string as $x =>$x_value)
   {
   	echo  $x_value;
   echo "<br>";
   	$hashPos =  strpos($x_value,"HASH");
   	$responceCodePos = strpos($x_value,"RESPONSE_CODE"); 
   	$statusPos = strpos($x_value,"STATUS"); 
   	if(is_numeric($responceCodePos)){
   		$responseCode = $x_value;
   	}
   	if(is_numeric($statusPos)){
		$status = $x_value;
   	}
   	if(is_numeric($hashPos)){
   		$hash = $x_value;
   		continue;
	}
   $sortedString = $sortedString.$x_value."~";

    
   }
   $trimString = rtrim($sortedString,"~");
   $saltToString = $trimString.$salt;
   $Generatedhash = hash('sha256', $saltToString) ;
   $Generatedhash=strtoupper($Generatedhash);

   $hash = ltrim($hash,"HASH=");
   $responseCode = ltrim($responseCode,"RESPONSE_CODE=");
   $status = ltrim($status,"STATUS=");

   if($Generatedhash == $hash && $responseCode == 000 && $status == "Captured" ){
   	echo "<h1>Payment Successful</h1>";
    

   }else{
   	 echo "<h1>Payment Fail</h1>";

   }
   
  
  
}

?>

